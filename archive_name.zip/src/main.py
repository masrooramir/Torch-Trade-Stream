# src/main.py
import sys
import os
from src.scraper.pipeline import DataPipeline 

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if __name__ == "__main__":
    ticker = input("Enter the stock ticker (e.g., AMZN, AAPL, TSLA): ").strip().upper()
    period = input("Enter the stock period in year(s) (e.g., 1y, 2y, 3y, 5y): ").strip().lower()
    print(ticker, period)
    
    if not ticker:
        ticker = "AAPL"  # Fallback default
        
    print(f"Starting historical pipeline for: {ticker}")
    pipeline = DataPipeline(ticker=ticker, sequence_length=60)
    
    # FIX IS HERE: Pass the period variable into the function!
    pipeline.run_historical_pipeline(period=period)
