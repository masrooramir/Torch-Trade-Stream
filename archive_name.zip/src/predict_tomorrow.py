# src/predict_tomorrow.py
import os
import sys
import numpy as np
import torch
import torch.nn as nn
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
os.chdir(BASE_DIR)
sys.path.append(BASE_DIR)

PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class LinearRegressionForecaster(nn.Module):
    def __init__(self, input_dim=60):
        super().__init__()
        self.linear = nn.Linear(input_dim, 1)
    def forward(self, x): return self.linear(x)

def run_automated_prediction(ticker="AMZN"):
    # 1. Load latest features and scaler parameters
    X_test = np.load(os.path.join(PROCESSED_DIR, f"{ticker}_X_test.npy"))
    scaler_params = np.load(os.path.join(PROCESSED_DIR, f"{ticker}_scaler_params.npy"))
    
    # 2. Reconstruct Model and load weights (assumes weights were saved)
    model = LinearRegressionForecaster(input_dim=60).to(device)
    # Note: In production, you would use torch.load('model.pth') here
    
    model.eval()
    with torch.no_grad():
        latest_window = torch.tensor(X_test[-1:], dtype=torch.float32).to(device)
        scaled_pred = model(latest_window).item()
    
    # 3. Decode
    real_price = (scaled_pred - scaler_params[0]) / scaler_params[1]
    
    # 4. Write to a daily log file
    log_path = os.path.join(BASE_DIR, "data", "predictions_log.txt")
    with open(log_path, "a") as f:
        f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {ticker} Tomorrow's Predicted Price: ${real_price:.2f}\n")
    print(f"🔮 Automated Prediction Logged: ${real_price:.2f}")

if __name__ == "__main__":
    run_automated_prediction("AMZN")
